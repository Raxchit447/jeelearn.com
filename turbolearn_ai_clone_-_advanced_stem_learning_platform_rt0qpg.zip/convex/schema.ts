import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  subjects: defineTable({
    name: v.string(),
    description: v.string(),
    icon: v.string(),
    color: v.string(),
  }),
  
  topics: defineTable({
    subjectId: v.id("subjects"),
    name: v.string(),
    description: v.string(),
    difficulty: v.union(v.literal("intermediate"), v.literal("advanced"), v.literal("expert")),
    prerequisites: v.array(v.string()),
  }).index("by_subject", ["subjectId"]),
  
  explanations: defineTable({
    userId: v.id("users"),
    topicId: v.id("topics"),
    query: v.string(),
    explanation: v.string(),
    difficulty: v.string(),
    concepts: v.array(v.string()),
    examples: v.array(v.string()),
    applications: v.array(v.string()),
  }).index("by_user", ["userId"])
    .index("by_topic", ["topicId"]),
  
  favorites: defineTable({
    userId: v.id("users"),
    explanationId: v.id("explanations"),
  }).index("by_user", ["userId"])
    .index("by_explanation", ["explanationId"]),
  
  learningProgress: defineTable({
    userId: v.id("users"),
    topicId: v.id("topics"),
    completedAt: v.number(),
    masteryLevel: v.union(v.literal("beginner"), v.literal("intermediate"), v.literal("advanced"), v.literal("expert")),
  }).index("by_user", ["userId"])
    .index("by_topic", ["topicId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
