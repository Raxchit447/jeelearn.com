import { action, query, mutation, internalQuery, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const generateExplanation = action({
  args: {
    topicId: v.id("topics"),
    query: v.string(),
    difficulty: v.string(),
  },
  handler: async (ctx, args): Promise<{ explanationId: any, explanation: string, concepts: string[], examples: string[], applications: string[] }> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to generate explanations");
    }

    const topic: any = await ctx.runQuery(internal.explanations.getTopic, { topicId: args.topicId });
    if (!topic) {
      throw new Error("Topic not found");
    }

    const subject: any = await ctx.runQuery(internal.explanations.getSubject, { subjectId: topic.subjectId });
    if (!subject) {
      throw new Error("Subject not found");
    }

    const prompt: string = `You are an expert ${subject.name} professor teaching at the most advanced level, beyond JEE Advanced. 

Topic: ${topic.name}
Subject: ${subject.name}
Student Query: ${args.query}
Difficulty Level: ${args.difficulty}

Provide a comprehensive, detailed explanation that includes:

1. **Core Concepts**: Deep theoretical understanding with mathematical rigor
2. **Advanced Theory**: Beyond undergraduate level, including latest research insights
3. **Mathematical Framework**: Detailed equations, derivations, and proofs where applicable
4. **Real-world Applications**: Current research applications and cutting-edge uses
5. **Interconnections**: How this connects to other advanced topics
6. **Problem-solving Approach**: Advanced techniques and methodologies

Make this explanation suitable for someone preparing for advanced competitive exams, graduate studies, or research. Include specific examples, case studies, and current developments in the field.

Format your response as a structured explanation with clear sections.`;

    const response: any = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: 4000,
    });

    const explanation: string | null = response.choices[0].message.content;
    if (!explanation) {
      throw new Error("Failed to generate explanation");
    }

    // Extract concepts, examples, and applications from the explanation
    const concepts = extractConcepts(explanation);
    const examples = extractExamples(explanation);
    const applications = extractApplications(explanation);

    const explanationId: any = await ctx.runMutation(internal.explanations.save, {
      userId,
      topicId: args.topicId,
      query: args.query,
      explanation,
      difficulty: args.difficulty,
      concepts,
      examples,
      applications,
    });

    return { explanationId, explanation, concepts, examples, applications };
  },
});

function extractConcepts(text: string): string[] {
  const conceptRegex = /(?:\*\*Core Concepts?\*\*|Core Concepts?:)(.*?)(?=\*\*|$)/is;
  const match = text.match(conceptRegex);
  if (!match) return [];
  
  return match[1]
    .split(/[•\-\n]/)
    .map(c => c.trim())
    .filter(c => c.length > 10)
    .slice(0, 5);
}

function extractExamples(text: string): string[] {
  const exampleRegex = /(?:example|case study|instance)/gi;
  const sentences = text.split(/[.!?]+/);
  return sentences
    .filter(s => exampleRegex.test(s))
    .map(s => s.trim())
    .slice(0, 3);
}

function extractApplications(text: string): string[] {
  const appRegex = /(?:\*\*.*?Applications?\*\*|Applications?:)(.*?)(?=\*\*|$)/is;
  const match = text.match(appRegex);
  if (!match) return [];
  
  return match[1]
    .split(/[•\-\n]/)
    .map(a => a.trim())
    .filter(a => a.length > 10)
    .slice(0, 5);
}

export const getTopic = internalQuery({
  args: { topicId: v.id("topics") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.topicId);
  },
});

export const getSubject = internalQuery({
  args: { subjectId: v.id("subjects") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.subjectId);
  },
});

export const save = internalMutation({
  args: {
    userId: v.id("users"),
    topicId: v.id("topics"),
    query: v.string(),
    explanation: v.string(),
    difficulty: v.string(),
    concepts: v.array(v.string()),
    examples: v.array(v.string()),
    applications: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("explanations", args);
  },
});

export const getUserExplanations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const explanations = await ctx.db
      .query("explanations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);

    return Promise.all(
      explanations.map(async (explanation) => {
        const topic = await ctx.db.get(explanation.topicId);
        const subject = topic ? await ctx.db.get(topic.subjectId) : null;
        return {
          ...explanation,
          topic,
          subject,
        };
      })
    );
  },
});

export const toggleFavorite = mutation({
  args: { explanationId: v.id("explanations") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in");
    }

    const existing = await ctx.db
      .query("favorites")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("explanationId"), args.explanationId))
      .unique();

    if (existing) {
      await ctx.db.delete(existing._id);
      return false;
    } else {
      await ctx.db.insert("favorites", {
        userId,
        explanationId: args.explanationId,
      });
      return true;
    }
  },
});
