import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("subjects").collect();
  },
});

export const getTopics = query({
  args: { subjectId: v.id("subjects") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("topics")
      .withIndex("by_subject", (q) => q.eq("subjectId", args.subjectId))
      .collect();
  },
});

export const seedSubjects = mutation({
  args: {},
  handler: async (ctx) => {
    const existingSubjects = await ctx.db.query("subjects").collect();
    if (existingSubjects.length > 0) return;

    const subjects = [
      {
        name: "Physics",
        description: "Advanced concepts in mechanics, thermodynamics, electromagnetism, and quantum physics",
        icon: "⚛️",
        color: "bg-blue-500",
      },
      {
        name: "Mathematics",
        description: "Complex analysis, differential equations, topology, and abstract algebra",
        icon: "📐",
        color: "bg-green-500",
      },
      {
        name: "Chemistry",
        description: "Organic synthesis, physical chemistry, and advanced inorganic concepts",
        icon: "🧪",
        color: "bg-purple-500",
      },
      {
        name: "Biology",
        description: "Molecular biology, biochemistry, genetics, and advanced physiology",
        icon: "🧬",
        color: "bg-emerald-500",
      },
    ];

    for (const subject of subjects) {
      await ctx.db.insert("subjects", subject);
    }
  },
});

export const seedTopics = mutation({
  args: {},
  handler: async (ctx) => {
    const existingTopics = await ctx.db.query("topics").collect();
    if (existingTopics.length > 0) return;

    const subjects = await ctx.db.query("subjects").collect();
    const physicsSubject = subjects.find(s => s.name === "Physics");
    const mathSubject = subjects.find(s => s.name === "Mathematics");
    const chemSubject = subjects.find(s => s.name === "Chemistry");
    const bioSubject = subjects.find(s => s.name === "Biology");

    if (!physicsSubject || !mathSubject || !chemSubject || !bioSubject) return;

    const topics = [
      // Physics Topics
      {
        subjectId: physicsSubject._id,
        name: "Quantum Field Theory",
        description: "Advanced quantum mechanics and field theory concepts",
        difficulty: "expert" as const,
        prerequisites: ["Quantum Mechanics", "Special Relativity", "Advanced Mathematics"],
      },
      {
        subjectId: physicsSubject._id,
        name: "General Relativity",
        description: "Einstein's theory of gravity and spacetime curvature",
        difficulty: "expert" as const,
        prerequisites: ["Special Relativity", "Tensor Calculus", "Differential Geometry"],
      },
      {
        subjectId: physicsSubject._id,
        name: "Statistical Mechanics",
        description: "Thermodynamics from a statistical perspective",
        difficulty: "advanced" as const,
        prerequisites: ["Thermodynamics", "Probability Theory", "Classical Mechanics"],
      },
      
      // Mathematics Topics
      {
        subjectId: mathSubject._id,
        name: "Complex Analysis",
        description: "Functions of complex variables and their properties",
        difficulty: "advanced" as const,
        prerequisites: ["Real Analysis", "Linear Algebra", "Multivariable Calculus"],
      },
      {
        subjectId: mathSubject._id,
        name: "Algebraic Topology",
        description: "Topological spaces and algebraic invariants",
        difficulty: "expert" as const,
        prerequisites: ["Abstract Algebra", "Point-Set Topology", "Homological Algebra"],
      },
      {
        subjectId: mathSubject._id,
        name: "Differential Geometry",
        description: "Geometry using calculus and linear algebra",
        difficulty: "advanced" as const,
        prerequisites: ["Multivariable Calculus", "Linear Algebra", "Real Analysis"],
      },
      
      // Chemistry Topics
      {
        subjectId: chemSubject._id,
        name: "Quantum Chemistry",
        description: "Application of quantum mechanics to chemical systems",
        difficulty: "expert" as const,
        prerequisites: ["Physical Chemistry", "Quantum Mechanics", "Linear Algebra"],
      },
      {
        subjectId: chemSubject._id,
        name: "Advanced Organic Synthesis",
        description: "Complex multi-step organic synthesis strategies",
        difficulty: "advanced" as const,
        prerequisites: ["Organic Chemistry", "Reaction Mechanisms", "Stereochemistry"],
      },
      
      // Biology Topics
      {
        subjectId: bioSubject._id,
        name: "Systems Biology",
        description: "Mathematical modeling of biological systems",
        difficulty: "expert" as const,
        prerequisites: ["Molecular Biology", "Biochemistry", "Mathematical Modeling"],
      },
      {
        subjectId: bioSubject._id,
        name: "Structural Biology",
        description: "3D structure and function of biological macromolecules",
        difficulty: "advanced" as const,
        prerequisites: ["Biochemistry", "Physical Chemistry", "Crystallography"],
      },
    ];

    for (const topic of topics) {
      await ctx.db.insert("topics", topic);
    }
  },
});
