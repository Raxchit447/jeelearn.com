import { useState, useEffect } from "react";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { Id } from "../convex/_generated/dataModel";
import { toast } from "sonner";

export function TurboLearnApp() {
  const [selectedSubject, setSelectedSubject] = useState<Id<"subjects"> | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Id<"topics"> | null>(null);
  const [query, setQuery] = useState("");
  const [difficulty, setDifficulty] = useState("advanced");
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentExplanation, setCurrentExplanation] = useState<any>(null);

  const subjects = useQuery(api.subjects.list);
  const topics = useQuery(api.subjects.getTopics, 
    selectedSubject ? { subjectId: selectedSubject } : "skip"
  );
  const userExplanations = useQuery(api.explanations.getUserExplanations);

  const seedSubjects = useMutation(api.subjects.seedSubjects);
  const seedTopics = useMutation(api.subjects.seedTopics);
  const generateExplanation = useAction(api.explanations.generateExplanation);
  const toggleFavorite = useMutation(api.explanations.toggleFavorite);

  useEffect(() => {
    if (subjects && subjects.length === 0) {
      seedSubjects().then(() => seedTopics());
    }
  }, [subjects, seedSubjects, seedTopics]);

  const handleGenerateExplanation = async () => {
    if (!selectedTopic || !query.trim()) {
      toast.error("Please select a topic and enter your question");
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateExplanation({
        topicId: selectedTopic,
        query: query.trim(),
        difficulty,
      });
      setCurrentExplanation(result);
      toast.success("Explanation generated successfully!");
    } catch (error) {
      toast.error("Failed to generate explanation");
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleToggleFavorite = async (explanationId: Id<"explanations">) => {
    try {
      const isFavorited = await toggleFavorite({ explanationId });
      toast.success(isFavorited ? "Added to favorites" : "Removed from favorites");
    } catch (error) {
      toast.error("Failed to update favorites");
    }
  };

  if (!subjects) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Advanced STEM Learning Platform
        </h1>
        <p className="text-gray-600">
          Get detailed explanations beyond JEE Advanced level
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Panel - Subject and Topic Selection */}
        <div className="lg:col-span-1 space-y-6">
          {/* Subjects */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-lg font-semibold mb-4">Select Subject</h2>
            <div className="grid grid-cols-2 gap-3">
              {subjects.map((subject) => (
                <button
                  key={subject._id}
                  onClick={() => {
                    setSelectedSubject(subject._id);
                    setSelectedTopic(null);
                    setCurrentExplanation(null);
                  }}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedSubject === subject._id
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="text-2xl mb-2">{subject.icon}</div>
                  <div className="text-sm font-medium">{subject.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Topics */}
          {selectedSubject && topics && (
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h2 className="text-lg font-semibold mb-4">Select Topic</h2>
              <div className="space-y-2">
                {topics.map((topic) => (
                  <button
                    key={topic._id}
                    onClick={() => {
                      setSelectedTopic(topic._id);
                      setCurrentExplanation(null);
                    }}
                    className={`w-full text-left p-3 rounded-lg border transition-all ${
                      selectedTopic === topic._id
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="font-medium text-sm">{topic.name}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {topic.difficulty} level
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main Panel - Query and Explanation */}
        <div className="lg:col-span-2 space-y-6">
          {/* Query Input */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-lg font-semibold mb-4">Ask Your Question</h2>
            <div className="space-y-4">
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter your detailed question about the selected topic..."
                className="w-full h-32 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              />
              
              <div className="flex items-center gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Difficulty Level
                  </label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                    <option value="expert">Expert</option>
                  </select>
                </div>
                
                <button
                  onClick={handleGenerateExplanation}
                  disabled={!selectedTopic || !query.trim() || isGenerating}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      🚀 Generate Explanation
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Current Explanation */}
          {currentExplanation && (
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">AI Explanation</h2>
                <button
                  onClick={() => handleToggleFavorite(currentExplanation.explanationId)}
                  className="text-yellow-500 hover:text-yellow-600"
                >
                  ⭐ Save
                </button>
              </div>
              
              <div className="prose max-w-none">
                <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                  {currentExplanation.explanation}
                </div>
              </div>

              {currentExplanation.concepts.length > 0 && (
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold text-blue-900 mb-2">Key Concepts</h3>
                  <div className="flex flex-wrap gap-2">
                    {currentExplanation.concepts.map((concept: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                      >
                        {concept}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Recent Explanations */}
          {userExplanations && userExplanations.length > 0 && (
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h2 className="text-lg font-semibold mb-4">Recent Explanations</h2>
              <div className="space-y-3">
                {userExplanations.slice(0, 5).map((explanation) => (
                  <div
                    key={explanation._id}
                    className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                    onClick={() => setCurrentExplanation({
                      explanation: explanation.explanation,
                      concepts: explanation.concepts,
                      examples: explanation.examples,
                      applications: explanation.applications,
                      explanationId: explanation._id,
                    })}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm">
                          {explanation.subject?.name} - {explanation.topic?.name}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {explanation.query.slice(0, 100)}...
                        </div>
                      </div>
                      <div className="text-xs text-gray-400">
                        {new Date(explanation._creationTime).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
